import pandas as pd
import math

header = "Event Time Date TimeStamp ADC1 ADC2 SiPM Tem Pressure DeadTime Coincident ID".split()
df = pd.read_csv("TopRight_20230803.txt", skiprows=7, names=header, sep='\t', index_col=False)

print(f"Q2: the size of the dataset is {len(df)}")
print(f"Q3: the mean of the Pressure is {df["Pressure"].mean()}")
pstd = df["Pressure"].std()
print(f"Q4: the uncertainty of the Pressure is {pstd / math.sqrt(len(df))}")

# ax1 = df.plot.scatter("TimeStamp", "Pressure")
# ax1.get_figure().savefig("pressure-vs-timestamp.jpg")


# ax2 = df.plot.scatter("TimeStamp", "SiPM")
# ax2.get_figure().savefig("simp-vs-timestamp.jpg")

print(f"Q7: the fraction of coindicent is {len(df[df["Coincident"]==1]) / len(df)}")

c1 = df[df["Coincident"]==1]["SiPM"]
c0 = df[df["Coincident"]==0]["SiPM"]

ax = c0.plot.hist(bins=50, alpha=0.5, range=[0,500],label = "no coincidence", density=True)
ax = c1.plot.hist(bins=50, alpha=0.5, range = [0,500],label = "coincidence", density=True)
ax.set_yscale("log")
ax.legend()
ax.get_figure().savefig("sipm-coin.jpg")

# c1.plot.hist( bins=50, alpha=0.5, range=[0,500],label = "coincidence", stat="density")
# # sipm1.get_figure().savefig("sipm-coin-1.jpg")
# sipm0 = c0.plot.hist( bins=50, alpha=0.5, range=[0,500],label = "no coincidence", stat="density")
# sipm0.get_figure().savefig("sipm-coin.jpg")

