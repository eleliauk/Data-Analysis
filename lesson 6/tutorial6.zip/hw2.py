import matplotlib.pyplot as plt
import numpy as np

with open("TopRight_20230803.txt", "r") as f:
  lines = f.readlines()
  data = lines[7:]
  timestamps = [0 for i in range(len(data))] # timestamps.append()
  print(f"number of entries: {len(data)}")
  for i in range(len(data)):
    entries = data[i].split('\t')
    timestamps[i] = float(entries[3])
  counts, bins, _ = plt.hist(timestamps, 100)
  plt.savefig('timestamps.jpg')
  rate = len(timestamps) / max(timestamps)
  print(f"rate: {rate}")
  errors = [abs(counts[i] / (bins[i+1] - bins[i]) - rate) for i in range(len(counts))]
  relative_error = sum(errors) / rate / len(counts)
  print(f'relative error: {relative_error}')
  uncertainty = np.std([counts[i] * 1000 / (bins[i+1] - bins[i]) for i in range(len(counts))])
  print(f"uncertainty: {uncertainty}")
  rela_unc = np.std([counts[i] * 1000 / (bins[i+1] - bins[i]) for i in range(len(counts))]) / np.mean([counts[i] * 1000 / (bins[i+1] - bins[i]) for i in range(len(counts))])
  print(f"uncertainty: {rela_unc}")
  print(len(data))
