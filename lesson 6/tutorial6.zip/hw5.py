import pandas as pd

df = pd.read_csv("data_HW5.txt")

print()
x1_cutoffs = [-1.5, 0, 1.5]
for x1 in x1_cutoffs:
  tp = df[(df["x1"] > x1) & (df["Type"] == " sig")]
  fp = df[(df["x1"] > x1) & (df["Type"] == " bkg")]
  tn = df[(df["x1"] <= x1) & (df["Type"] == " bkg")]
  fn = df[(df["x1"] <= x1) & (df["Type"] == " sig")]
  purity = len(tp) / (len(tp) + len(fp))
  efficiency = len(tp) / (len(tp) + len(fn))
  print(f"Purity of {x1} is {purity}")
  print(f"Efficiency of {x1} is {efficiency}")


print()
x2_cutoffs = [-3, 0, 2, 3]
for x2 in x2_cutoffs:
  tp = df[(df["x2"] > x2) & (df["Type"] == " sig")]
  fp = df[(df["x2"] > x2) & (df["Type"] == " bkg")]
  tn = df[(df["x2"] <= x2) & (df["Type"] == " bkg")]
  fn = df[(df["x2"] <= x2) & (df["Type"] == " sig")]
  purity = len(tp) / (len(tp) + len(fp))
  efficiency = len(tp) / (len(tp) + len(fn))
  print(f"Purity of {x2} is {purity}")
  print(f"Efficiency of {x2} is {efficiency}")

print()
x3_cutoffs = [0, 0.25, 0.75, 0.9]
for x3 in x3_cutoffs:
  tp = df[(df["x3"] > x3) & (df["Type"] == " sig")]
  fp = df[(df["x3"] > x3) & (df["Type"] == " bkg")]
  tn = df[(df["x3"] <= x3) & (df["Type"] == " bkg")]
  fn = df[(df["x3"] <= x3) & (df["Type"] == " sig")]
  purity = len(tp) / (len(tp) + len(fp))
  efficiency = len(tp) / (len(tp) + len(fn))
  print(f"Purity of {x3} is {purity}")
  print(f"Efficiency of {x3} is {efficiency}")